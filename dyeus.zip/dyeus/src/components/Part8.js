const Part8 = () => <div className="part8">
    With Diana, you’re in control of your health, your every day, and your story.
</div>

export default Part8;